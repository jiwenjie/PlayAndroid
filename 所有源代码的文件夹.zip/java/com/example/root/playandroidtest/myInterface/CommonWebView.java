package com.example.root.playandroidtest.myInterface;

import android.widget.ProgressBar;

/**
 * Created by Root on 2018/3/14.
 *  WebView
 */

public interface CommonWebView {

    ProgressBar getProgressBar();

    void setTitle(String title);
}
