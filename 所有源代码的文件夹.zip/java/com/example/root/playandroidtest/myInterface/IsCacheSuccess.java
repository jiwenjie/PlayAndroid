package com.example.root.playandroidtest.myInterface;

/**
 * Created by Root on 2018/3/18.
 *
 * 缓存到运存中是否成功的回掉接口
 */

public interface IsCacheSuccess {

    void CacheSuccess();

    void CacheFailed();
}
