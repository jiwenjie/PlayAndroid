package com.example.root.playandroidtest.myInterface;

/**
 * Created by Root on 2018/3/18.
 *
 * 缓存到本地是否成功的回掉接口
 */

public interface IsDiskCacheData {

    void DiskCacheSuccess();

    void DiskCacheFailed();
}
