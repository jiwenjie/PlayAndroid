package com.example.root.playandroidtest.activity;

import android.os.Bundle;

import com.example.root.playandroidtest.R;

/**
 * Created by Root on 2018/3/19.
 */

public class AboutActivity extends BaseActivity {

    @Override
    protected void initViews(Bundle savedInstanceState) {
        setContentView(R.layout.activity_about);
    }

    @Override
    protected void loadData() {

    }
}
