package com.example.root.playandroidtest.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.example.root.playandroidtest.R;
//import com.example.root.playandroidtest.adapter.HomeBaseRecycleViewAdapter;
import com.example.root.playandroidtest.adapter.ArticleListAdapter;
import com.example.root.playandroidtest.adapter.HomeDataAdapter;
import com.example.root.playandroidtest.app.AppConst;
import com.example.root.playandroidtest.app.MyApplication;
import com.example.root.playandroidtest.bean.ArticleBean;
import com.example.root.playandroidtest.util.GetHomeData;
import com.example.root.playandroidtest.util.ParserJsonWebData;
import com.example.root.playandroidtest.util.T;
import com.example.root.playandroidtest.util.WebConnectUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;

/**
 * Created by Root on 2018/3/13.
 * 首页 Fragment
 */

public class HomeFragment extends Fragment {

    private SwipeRefreshLayout swipeRefresh;
    private RecyclerView recyclerView;

    private int int_page = 0;  //访问网络数据的当前代表页（从0开始）

//    private List<ArticleBean> beanList;
//    HomeDataAdapter homeDataAdapter;
//
//    TextView index_home_textView;
//
//    private String homeData = "";

    public HomeFragment() {  }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

//        requestWindowFeature(Window.FEATURE_NO_TITLE);
        View rootView = inflater.inflate(R.layout.fragment_home,container,false);
        initViewContent(rootView);
        doClick();

        return rootView;
    }

    private void doClick(){

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refresh();
            }
        });

    }

    private void refresh() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                    showRefreshView(false);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }).start();

    }


    private void initViewContent(View rootView) {
        swipeRefresh = (SwipeRefreshLayout)rootView.findViewById(R.id.swipe_refresh);
        swipeRefresh.setColorSchemeColors(getResources().getColor(R.color.colorPrimary));
        recyclerView = (RecyclerView) rootView.findViewById(R.id.index_home_recycleView_data);
        LinearLayoutManager manager = new LinearLayoutManager(MyApplication.getContext());
        recyclerView.setLayoutManager(manager);
        String url = AppConst.getUrl(int_page);
        GetRefreshData(url);

    }

    //获取首页数据
    private void GetRefreshData(String address) {

//        final String refreshData = "";
        //获取数据
        WebConnectUtil.sendRequestWidthOkHttp(address, new okhttp3.Callback() {

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //获取服务器返回的具体内容
                final String responseData = response.body().string();

                getActivity().runOnUiThread(
                        new Runnable() {
                    @Override
                    public void run() {
                        List<ArticleBean> getDataList = ParserJsonWebData.parseJsonWithGSON(responseData);
//                       List<ArticleBean> getDataList = ParserJsonWebData.parseJSONWITHJSONObject(responseData);
                        if (getDataList==null) {
                            T.showShort(MyApplication.getContext(), "首页数据对象为空");
                        }

                        //找出当前的一共多少个对象（List中有多少个对象）
                        int size = getDataList.size();
                        T.showShort(MyApplication.getContext(), "一共有" + size + "个对象");

                        ArticleListAdapter adapter = new ArticleListAdapter(MyApplication.getContext(), getDataList);
                        //设置item的动画效果
                        adapter.openLoadAnimation(BaseQuickAdapter.SCALEIN);
                        //设置重复执行动画
                        adapter.isFirstOnly(false);
                        //预加载功能，设置滑倒第几个item的时候开始回掉接口
                        adapter.setAutoLoadMoreSize(5);
                        // 滑动最后一个Item的时候回调onLoadMoreRequested方法
//                        setOnLoadMoreListener(RequestLoadMoreListener);
                        //获取上拉加载更多
                        getMoreData(adapter, size);

                        //设置适配器
                        recyclerView.setAdapter(adapter);
//                        HomeDataAdapter homeDataAdapter = new HomeDataAdapter(getDataList);
//                        recyclerView.setAdapter(homeDataAdapter);
                    }
                });
            }

            @Override
            public void onFailure(Call call, IOException e) {
                T.showShort(MyApplication.getContext(), "没有获取到网络数据");
            }
        });

    }



    //展示是否需要隐藏刷新图标
    public void showRefreshView(final Boolean refresh) {
        swipeRefresh.post(new Runnable() {
            @Override
            public void run() {
                swipeRefresh.setRefreshing(refresh);
            }
        });
    }


    //调用了接口回掉方法（加载更多）
    private void getMoreData(ArticleListAdapter listAdapter, int length) {

        listAdapter.setOnLoadMoreListener(new BaseQuickAdapter.RequestLoadMoreListener() {
            @Override
            public void onLoadMoreRequested() {

                recyclerView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        boolean isErr = false;
                        if (length >= AppConst.ITEM_SIZE) {
                            //一个界面的数据加载完毕
                            listAdapter.loadMoreEnd();
                        } else {

                            if (isErr) {

                                //成功获取更多数据
//                            listAdapter.addData();
                                MoreData(int_page++);
                                //主调用加载完成，停止加载
                                listAdapter.loadMoreComplete();
                            } else {
                                //获取更多数据失败
                                //isErr = true;
//                                Toast.makeText(PullToRefreshUseActivity.this, R.string.network_err, Toast.LENGTH_LONG).show();
                                //同理，加载失败也要主动调用加载失败来停止加载（而且该方法会提示加载失败）
                                listAdapter.loadMoreFail();

                            }

                        }
                    }

                }, 2000);
            }
        });
    }


    //实际操作获取更多数据
    private void MoreData(int page) {
        String addr = AppConst.getUrl(page);
        GetRefreshData(addr);
        

    }

}
